Hi! 

Thank you for supporting Wej!

To connect Wej to your computer and program it you will want a Pocket AVR Programmer:
https://www.sparkfun.com/products/9825

You will also need the Arduino software:
https://www.arduino.cc/en/Main/Software

By reprogramming the Wej you should be able to:
-Bridge joysticks, keyboards or other USB devices to MIDI
-Create new light patterns
-Add USB Hub support

I've included the original firmware so that you can reprogram the original state.
wej_ino.cpp.hex


Please send me any questions, comments or successes:
dan@retronyms.com


